import React from 'react';
import { FolderRoot as Football, Instagram, Mail, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gamba-navy-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center mb-6 md:mb-0">
            <Football size={32} className="text-gamba-blue-400" />
            <span className="ml-2 text-xl font-bold">Gamba Osaka Tickets</span>
          </div>
          
          <div className="flex space-x-6">
            <a 
              href="https://www.instagram.com/global_gamba_osaka_/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white hover:text-gamba-blue-300 transition-colors"
            >
              <Instagram size={24} />
            </a>
            <a 
              href="mailto:info@globalgambaosaka.com" 
              className="text-white hover:text-gamba-blue-300 transition-colors"
            >
              <Mail size={24} />
            </a>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 pb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#how-to-buy" className="text-white/70 hover:text-white transition-colors">
                    How to Buy Tickets
                  </a>
                </li>
                <li>
                  <a href="#seating" className="text-white/70 hover:text-white transition-colors">
                    Seating Categories
                  </a>
                </li>
                <li>
                  <a href="#about-club" className="text-white/70 hover:text-white transition-colors">
                    About Gamba Osaka
                  </a>
                </li>
                <li>
                  <a href="#about-ggo" className="text-white/70 hover:text-white transition-colors">
                    About GGO
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Official Links</h4>
              <ul className="space-y-2">
                <li>
                  <a 
                    href="https://www.jleague-ticket.jp/club/go/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-white/70 hover:text-white transition-colors"
                  >
                    J.League Ticket Site
                  </a>
                </li>
                <li>
                  <a 
                    href="https://www.gamba-osaka.net/en/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-white/70 hover:text-white transition-colors"
                  >
                    Gamba Osaka Official Site
                  </a>
                </li>
                <li>
                  <a 
                    href="https://www.jleague.jp/en/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-white/70 hover:text-white transition-colors"
                  >
                    J.League Official Site
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li>
                  <a 
                    href="https://www.instagram.com/global_gamba_osaka_/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-white/70 hover:text-white transition-colors"
                  >
                    Contact GGO
                  </a>
                </li>
                <li>
                  <a href="#faq" className="text-white/70 hover:text-white transition-colors">
                    FAQs
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Language</h4>
              <div className="flex space-x-2">
                <button className="bg-gamba-blue-700 text-white px-3 py-1 rounded">
                  English
                </button>
                <button className="bg-white/10 text-white/70 hover:bg-white/20 px-3 py-1 rounded transition-colors">
                  日本語
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/60 text-sm">
            © {new Date().getFullYear()} Global Gamba Osaka. This is an unofficial fan site.
          </p>
          
          <button 
            onClick={scrollToTop}
            className="mt-4 md:mt-0 bg-gamba-blue-800 hover:bg-gamba-blue-700 text-white p-2 rounded-full transition-colors"
          >
            <ArrowUp size={20} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;