import React from 'react';
import { Instagram, Users, MessageCircle, Globe } from 'lucide-react';
import Football from './Football';

const AboutGGO = () => {
  return (
    <section id="about-ggo" className="section-container bg-gamba-blue-900 text-white">
      <h2 className="section-title text-white">About GGO (Global Gamba Osaka)</h2>
      
      <div className="max-w-4xl mx-auto text-center mb-12">
        <div className="flex justify-center mb-8">
          <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center">
            <Football size={40} className="text-gamba-blue-700" />
          </div>
        </div>
        
        <p className="text-white/90 text-lg mb-6">
          Global Gamba Osaka (GGO) 🔵⚫️ is an international community of Gamba Osaka supporters, 
          creating a welcoming environment for foreign and Japanese fans alike.
        </p>
        
        <p className="text-white/90 text-lg mb-6">
          ガンバ大阪🔵⚫️を応援するコミュニティを作っています🔥日本＆海外サポーター大歓迎です！
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <div className="flex items-center bg-white/10 px-5 py-3 rounded-lg">
            <Users className="text-white mr-2" size={20} />
            <span>International Community</span>
          </div>
          <div className="flex items-center bg-white/10 px-5 py-3 rounded-lg">
            <MessageCircle className="text-white mr-2" size={20} />
            <span>Match Info in English</span>
          </div>
          <div className="flex items-center bg-white/10 px-5 py-3 rounded-lg">
            <Globe className="text-white mr-2" size={20} />
            <span>Supporter Events</span>
          </div>
        </div>
      </div>
      
      <div className="bg-gamba-navy-500 rounded-xl p-6 md:p-10 max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2">
            <h3 className="text-2xl font-semibold mb-4">Connect with GGO</h3>
            <p className="text-white/80 mb-6">
              Follow us on Instagram for the latest updates, match information, and supporter events. 
              We're here to help international fans enjoy the Gamba Osaka experience to the fullest.
            </p>
            <div className="flex flex-col space-y-4">
              <a 
                href="https://www.instagram.com/global_gamba_osaka_/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-white text-gamba-blue-800 hover:bg-gray-100 
                font-medium py-3 px-6 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl 
                transform hover:-translate-y-1"
              >
                <Instagram className="mr-2" size={20} />
                Follow on Instagram
              </a>
              <a 
                href="https://www.instagram.com/global_gamba_osaka_/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-transparent text-white border-2 border-white 
                hover:bg-white/10 font-medium py-3 px-6 rounded-lg transition-all duration-300"
              >
                Contact Global Gamba Osaka
              </a>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="w-64 h-64 rounded-xl bg-white/10 flex items-center justify-center">
              <Instagram size={80} className="text-white/50" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutGGO;