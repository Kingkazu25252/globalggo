import React from 'react';

const Hero = () => {
  return (
    <div 
      className="relative h-screen bg-cover bg-center" 
      style={{ backgroundImage: "url('https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg')" }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-gamba-navy-900/70 to-gamba-blue-900/60"></div>
      <div className="relative h-full flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 animate-slide-up">
          Gamba Osaka Tickets
        </h1>
        <p className="text-xl md:text-2xl text-white/90 max-w-2xl animate-slide-up" style={{animationDelay: '0.2s'}}>
          Your English guide to supporting Gamba Osaka at Panasonic Stadium Suita
        </p>
        <div className="mt-10 animate-slide-up" style={{animationDelay: '0.4s'}}>
          <a 
            href="#how-to-buy" 
            className="btn-primary"
          >
            Get Your Tickets
          </a>
        </div>
      </div>
      <div className="absolute bottom-8 left-0 right-0 flex justify-center">
        <div className="animate-bounce">
          <svg className="w-6 h-6 text-white" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default Hero;