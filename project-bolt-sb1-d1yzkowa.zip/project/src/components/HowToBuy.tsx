import React from 'react';
import { ExternalLink, CreditCard, Ticket, Calendar } from 'lucide-react';

const HowToBuy = () => {
  return (
    <section id="how-to-buy" className="section-container bg-white">
      <h2 className="section-title">How to Buy Tickets</h2>
      
      <div className="max-w-4xl mx-auto bg-yellow-50 border-l-4 border-yellow-400 p-4 md:p-6 rounded-r-lg mb-12">
        <h3 className="font-semibold text-xl text-yellow-800 mb-2">Important Information</h3>
        <p className="text-yellow-800">
          Using the English J League website for purchases results in higher service fees. 
          We recommend using the Japanese site for better rates. 
          For assistance or questions, contact Global Gamba Osaka on Instagram.
        </p>
      </div>
      
      <div className="space-y-8 md:space-y-12">
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-1 flex justify-center">
            <div className="w-16 h-16 bg-gamba-blue-100 rounded-full flex items-center justify-center">
              <Calendar className="w-8 h-8 text-gamba-blue-700" />
            </div>
          </div>
          <div className="md:col-span-4">
            <h3 className="section-subtitle">1. Visit the J League (Gamba Osaka) Ticket Site</h3>
            <p className="text-gray-700 mb-4">
              Navigate to the official J League ticket website. For lower fees and better rates, we recommend creating a J League account on the Japanese website.
            </p>
            <a 
              href="https://www.jleague-ticket.jp/club/go/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center text-gamba-blue-700 hover:text-gamba-blue-500 font-medium"
            >
              Go to J League Ticket Site
              <ExternalLink className="ml-1 w-4 h-4" />
            </a>
          </div>
        </div>
        
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-1 flex justify-center">
            <div className="w-16 h-16 bg-gamba-blue-100 rounded-full flex items-center justify-center">
              <Calendar className="w-8 h-8 text-gamba-blue-700" />
            </div>
          </div>
          <div className="md:col-span-4">
            <h3 className="section-subtitle">2. Select Your Match</h3>
            <p className="text-gray-700">
              Choose Gamba Osaka from the club list, browse the upcoming fixtures, and select the match you wish to attend.
            </p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-1 flex justify-center">
            <div className="w-16 h-16 bg-gamba-blue-100 rounded-full flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-gamba-blue-700" />
            </div>
          </div>
          <div className="md:col-span-4">
            <h3 className="section-subtitle">3. Complete Your Purchase</h3>
            <p className="text-gray-700">
              Select your preferred seating category, the number of tickets, and proceed to checkout. 
              Payment can be made using major credit cards.
            </p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-1 flex justify-center">
            <div className="w-16 h-16 bg-gamba-blue-100 rounded-full flex items-center justify-center">
              <Ticket className="w-8 h-8 text-gamba-blue-700" />
            </div>
          </div>
          <div className="md:col-span-4">
            <h3 className="section-subtitle">4. Receive Your Tickets</h3>
            <p className="text-gray-700 mb-4">
              E-tickets will be sent to your email and can be displayed on your smartphone at the stadium entrance or printed if preferred.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-12 flex flex-col md:flex-row items-center justify-center gap-6">
        <a 
          href="https://www.jleague-ticket.jp/club/go/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="btn-primary w-full md:w-auto text-center"
        >
          Buy Tickets Now
        </a>
        <a 
          href="https://www.instagram.com/global_gamba_osaka_/" 
          target="_blank"
          rel="noopener noreferrer"
          className="btn-primary w-full md:w-auto text-center bg-gamba-blue-600"
        >
          Contact Global Gamba Osaka
        </a>
      </div>
    </section>
  );
};

export default HowToBuy;