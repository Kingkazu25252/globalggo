import React from 'react';
import { Trophy, Home, History } from 'lucide-react';

const AboutClub = () => {
  const achievements = [
    { year: 2008, competition: 'AFC Champions League', placement: 'Champions' },
    { year: 2014, competition: 'J1 League', placement: 'Champions' },
    { year: 2008, competition: "Emperor's Cup", placement: 'Champions' },
    { year: 2007, competition: "Emperor's Cup", placement: 'Champions' },
    { year: 2004, competition: 'J.League Cup', placement: 'Champions' },
    { year: 2007, competition: 'J.League Cup', placement: 'Champions' },
    { year: 2014, competition: 'Japanese Super Cup', placement: 'Champions' },
  ];

  return (
    <section id="about-club" className="section-container bg-white">
      <h2 className="section-title">About Gamba Osaka</h2>
      
      <div className="grid md:grid-cols-3 gap-8">
        <div className="card p-6 md:p-8">
          <div className="mb-4 text-gamba-blue-600">
            <Home size={32} />
          </div>
          <h3 className="text-xl font-semibold mb-4">Stadium</h3>
          <p className="text-gray-700 mb-4">
            Panasonic Stadium Suita is Gamba Osaka's home ground, a modern football-specific stadium opened in 2016. With a capacity of 39,694, the stadium provides an intimate atmosphere with excellent views from all seats.
          </p>
          <p className="text-gray-700">
            The stadium is known for its steep stands that keep fans close to the action and its excellent facilities including wide concourses, good food options, and clean amenities.
          </p>
        </div>
        
        <div className="card p-6 md:p-8">
          <div className="mb-4 text-gamba-blue-600">
            <History size={32} />
          </div>
          <h3 className="text-xl font-semibold mb-4">History</h3>
          <p className="text-gray-700 mb-4">
            Founded in 1980 as Matsushita Electric Industrial Co. Football Club, the team was among the founding members of the J.League in 1993, rebranding as Gamba Osaka.
          </p>
          <p className="text-gray-700">
            The club experienced its golden era in the mid-2000s to early 2010s, winning the AFC Champions League in 2008 and the J1 League title in 2014. Gamba is known for its attacking philosophy and has produced many Japanese internationals.
          </p>
        </div>
        
        <div className="card p-6 md:p-8">
          <div className="mb-4 text-gamba-blue-600">
            <Trophy size={32} />
          </div>
          <h3 className="text-xl font-semibold mb-4">Major Honors</h3>
          <ul className="space-y-2 text-gray-700">
            {achievements.map((achievement, index) => (
              <li key={index} className="flex justify-between items-center border-b border-gray-100 pb-2">
                <span>{achievement.competition}</span>
                <span className="font-medium">{achievement.year}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="mt-12 relative overflow-hidden rounded-xl">
        <img 
          src="https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg" 
          alt="Gamba Osaka Stadium" 
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gamba-blue-900/80 to-transparent flex items-center">
          <div className="p-6 md:p-12 max-w-lg">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Join Us For The Next Match</h3>
            <p className="text-white/90 mb-6">
              Experience the passion and energy of Japanese football at Panasonic Stadium Suita. Be part of the blue and black army!
            </p>
            <a 
              href="https://www.jleague-ticket.jp/club/go/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white text-gamba-blue-800 hover:bg-gray-100 font-medium py-3 px-6 rounded-lg 
              transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Find Upcoming Matches
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutClub;