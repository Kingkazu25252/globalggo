import React from 'react';

interface FootballProps {
  size?: number;
  className?: string;
}

const Football: React.FC<FootballProps> = ({ size = 24, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 2a8.1 8.1 0 0 1 7.5 5.5h-15A8.1 8.1 0 0 1 12 4zm0 16a8.1 8.1 0 0 1-7.5-5.5h15A8.1 8.1 0 0 1 12 20zm9.5-7.5a8 8 0 0 1-9.5 7.5c-3.8 0-7-2.7-7.5-6.5z" />
      <path d="M12 7v10M7 9l10 6M7 15l10-6" />
    </svg>
  );
};

export default Football;