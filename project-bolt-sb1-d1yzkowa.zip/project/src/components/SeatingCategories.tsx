import React from 'react';

const SeatingCategories = () => {
  const categories = [
    {
      name: 'Home Supporters',
      priceRange: '¥2,800 - ¥3,000',
      description: 'Join the passionate Gamba Osaka supporter sections where fans create an electric atmosphere with chants, songs, and choreographed displays. Perfect for those looking to experience the most vibrant matchday environment.',
      image: 'https://images.pexels.com/photos/114296/pexels-photo-114296.jpeg',
    },
    {
      name: 'Side Stands',
      priceRange: '¥4,000 - ¥7,000',
      description: 'Excellent viewing positions along the sides of the pitch offering a great perspective of the game. These seats provide a balanced view of the action with varying price points depending on height and position.',
      image: 'https://images.pexels.com/photos/270085/pexels-photo-270085.jpeg',
    },
    {
      name: 'Family Zone',
      priceRange: '¥4,000 - ¥6,000',
      description: 'Designated areas perfect for families with children. These sections offer a more relaxed atmosphere while still providing good views of the match. Special amenities for children may be available.',
      image: 'https://images.pexels.com/photos/4578168/pexels-photo-4578168.jpeg',
    },
    {
      name: 'Premium Seats',
      priceRange: '¥8,000 - ¥12,000',
      description: 'The most comfortable seating options with the best views in the stadium. Premium seats often include additional services such as wider seats, food service options, and prime central locations.',
      image: 'https://images.pexels.com/photos/207891/pexels-photo-207891.jpeg',
    },
  ];

  return (
    <section id="seating" className="section-container bg-gray-50">
      <h2 className="section-title">Seating Categories</h2>
      
      <div className="grid md:grid-cols-2 gap-8">
        {categories.map((category, index) => (
          <div 
            key={index} 
            className="card group overflow-hidden"
          >
            <div className="h-48 overflow-hidden relative">
              <img 
                src={category.image} 
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-4 md:p-6 w-full">
                  <h3 className="text-xl font-bold text-white">{category.name}</h3>
                  <p className="text-white/90 font-medium">{category.priceRange}</p>
                </div>
              </div>
            </div>
            <div className="p-4 md:p-6">
              <p className="text-gray-700">{category.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-xl font-semibold text-gamba-blue-800 mb-4">Seating Tips</h3>
        <ul className="space-y-2 text-gray-700">
          <li className="flex items-start">
            <span className="text-gamba-blue-500 mr-2">•</span>
            <span>Tickets for high-profile matches and derbies may sell out quickly, so purchase early.</span>
          </li>
          <li className="flex items-start">
            <span className="text-gamba-blue-500 mr-2">•</span>
            <span>The Home Supporters sections require active participation in chanting and supporting.</span>
          </li>
          <li className="flex items-start">
            <span className="text-gamba-blue-500 mr-2">•</span>
            <span>For the best view of the game, the central areas of the Side Stands are recommended.</span>
          </li>
          <li className="flex items-start">
            <span className="text-gamba-blue-500 mr-2">•</span>
            <span>Premium Seats often include access to indoor facilities and sometimes food and beverage services.</span>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default SeatingCategories;