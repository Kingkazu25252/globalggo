import React, { useState, useEffect } from 'react';
import { Menu, X, FolderRoot as Football } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToSection = (id: string) => {
    setIsMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="flex items-center">
                <Football size={32} className="text-gamba-blue-700" />
                <span className="ml-2 text-xl font-bold text-gamba-blue-900">Gamba Osaka Tickets</span>
              </div>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('how-to-buy')}
                className="text-gamba-blue-800 hover:text-gamba-blue-600 font-medium transition-colors"
              >
                How to Buy
              </button>
              <button 
                onClick={() => scrollToSection('seating')}
                className="text-gamba-blue-800 hover:text-gamba-blue-600 font-medium transition-colors"
              >
                Seating
              </button>
              <button 
                onClick={() => scrollToSection('about-club')}
                className="text-gamba-blue-800 hover:text-gamba-blue-600 font-medium transition-colors"
              >
                About Gamba
              </button>
              <button 
                onClick={() => scrollToSection('about-ggo')}
                className="text-gamba-blue-800 hover:text-gamba-blue-600 font-medium transition-colors"
              >
                About GGO
              </button>
            </div>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gamba-blue-700 hover:text-gamba-blue-900 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg animate-fade-in">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button 
              onClick={() => scrollToSection('how-to-buy')}
              className="block px-3 py-4 w-full text-left text-gamba-blue-800 hover:bg-gamba-blue-50 font-medium border-b border-gray-100"
            >
              How to Buy Tickets
            </button>
            <button 
              onClick={() => scrollToSection('seating')}
              className="block px-3 py-4 w-full text-left text-gamba-blue-800 hover:bg-gamba-blue-50 font-medium border-b border-gray-100"
            >
              Seating Categories
            </button>
            <button 
              onClick={() => scrollToSection('about-club')}
              className="block px-3 py-4 w-full text-left text-gamba-blue-800 hover:bg-gamba-blue-50 font-medium border-b border-gray-100"
            >
              About Gamba Osaka
            </button>
            <button 
              onClick={() => scrollToSection('about-ggo')}
              className="block px-3 py-4 w-full text-left text-gamba-blue-800 hover:bg-gamba-blue-50 font-medium"
            >
              About GGO
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;