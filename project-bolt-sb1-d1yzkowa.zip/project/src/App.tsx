import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import HowToBuy from './components/HowToBuy';
import AboutGGO from './components/AboutGGO';
import SeatingCategories from './components/SeatingCategories';
import AboutClub from './components/AboutClub';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      <Hero />
      <main className="flex-grow">
        <HowToBuy />
        <AboutGGO />
        <SeatingCategories />
        <AboutClub />
      </main>
      <Footer />
    </div>
  );
}

export default App